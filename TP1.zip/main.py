import flet as ft
import os
from cryptography.fernet import Fernet
from dotenv import load_dotenv
from flet.auth.providers import GitHubOAuthProvider
from flet import ElevatedButton, LoginEvent, Page


load_dotenv()

GITHUB_CLIENT_ID = os.getenv("GITHUB_CLIENT_ID")
assert GITHUB_CLIENT_ID, "set GITHUB_ID enviroment variable"
GITHUB_CLIENT_SECRET = os.getenv("GITHUB_CLIENT_SECRET")
assert GITHUB_CLIENT_SECRET, "set GITHUB_SECRET enviroment variable"

encryption_key = os.getenv("ENCRYPTION_KEY")

chave = Fernet(encryption_key.encode())

def encrypt_data(data):
    return chave.encrypt(data.encode()).decode()

def decrypt_data(encrypted_data):
    return chave.decrypt(encrypted_data.encode()).decode()


class Task(ft.UserControl):
    def __init__(self, task_name, task_status_change, task_delete, completed=False):
        super().__init__()
        #self.todo_app = todo_app
        self.task_name = task_name
        self.task_status_change = task_status_change
        self.task_delete = task_delete
        self.completed = completed

    def build(self):
        self.display_task = ft.Checkbox(value=self.completed, label=self.task_name, on_change=self.status_changed)
        self.edit_name = ft.TextField(expand=1)

        self.display_view = ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                self.display_task,
                ft.Row(
                    spacing=0,
                    controls=[
                        ft.IconButton(
                            icon=ft.icons.CREATE_OUTLINED,
                            tooltip="Edit To-Do",
                            on_click=self.edit_clicked,
                        ),
                        ft.IconButton(
                            icon=ft.icons.DELETE_OUTLINE,
                            tooltip="Delete To-Do",
                            on_click=self.delete_clicked,
                        ),
                    ],
                ),
            ],
        )

        self.edit_view = ft.Row(
            visible=False,
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                self.edit_name,
                ft.IconButton(
                    icon=ft.icons.DONE_OUTLINE_OUTLINED,
                    icon_color=ft.colors.GREEN,
                    tooltip="Update To-Do",
                    on_click=self.save_clicked,
                ),
            ],
        )
        return ft.Column(controls=[self.display_view, self.edit_view])

    def edit_clicked(self, e):
        self.edit_name.value = self.task_name
        self.display_view.visible = False
        self.edit_view.visible = True
        self.update()

    def save_clicked(self, e):
        old_task_name_encrypted = encrypt_data(self.task_name)  # Encripta o nome antigo da task
        self.task_name = self.edit_name.value  # Atualize o nome da task 
        new_task_name_encrypted = encrypt_data(self.task_name)  # Encripta de novo

        self.display_task.label = self.task_name  #para aparecer descriptogrado para o user

    
        self.page.client_storage.remove(f"todo.{old_task_name_encrypted}")  # Remova a entrada antiga usando a versão encriptada
        self.page.client_storage.set(f"todo.{new_task_name_encrypted}", self.completed)  # Defina a nova entrada com o nome encriptado

        # Atualize a exibição
        self.display_view.visible = True
        self.edit_view.visible = False
        self.update()


    def delete_clicked(self, e):
        self.task_delete(self)

    def status_changed(self, e):
        self.completed = self.display_task.value
        encrypted_task_name = encrypt_data(self.task_name)  # Apenas encriptar o nome da tarefa
        self.page.client_storage.set(f"todo.{encrypted_task_name}", self.completed)  # Armazenar o status sem encriptação com o nome da tarefa encriptado
        self.task_status_change()


        

class TodoApp(ft.UserControl):
    def __init__(self,page):
        super().__init__()
        self.tasks = []
        self.new_task = ft.TextField(hint_text="What needs to be done?", expand=True)
        self.tasks_view = ft.Column()
        self.page=page
        #self.status =  self.page.client_storage.get(key)

        self.filter = ft.Tabs(
            selected_index=0,
            on_change=self.tabs_changed,
            tabs=[ft.Tab(text="All"), ft.Tab(text="Active"), ft.Tab(text="Completed")],
        )
        self.items_left = ft.Text("0 items left")

        #self.load_tasks()  # Carrega tarefas do armazenamento local ao iniciar
    
    def build(self):
        return ft.Column(
            width=600,
            controls=[
                ft.Row(
                    controls=[
                        self.new_task,
                        ft.FloatingActionButton(icon=ft.icons.ADD, on_click=self.add_clicked),
                    ],
                ),
                self.filter,
                self.tasks_view,
                ft.Row(
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    controls=[
                        self.items_left,
                        ft.OutlinedButton(text="Clear completed", on_click=self.clear_clicked),
                    ],
                ),
            ],  
        )
    def did_mount(self):
        keys = self.page.client_storage.get_keys("todo.")
        for key in keys:
            completed = self.page.client_storage.get(key)
            encrypted_task_name = key.replace("todo.", "")
            task_name = decrypt_data(encrypted_task_name)  # descriptogra o nome da task
            task = Task(task_name, self.update, self.task_delete, completed)
            self.tasks.append(task)
            self.tasks_view.controls.append(task)
        self.update() 

        
    def add_clicked(self, e):
        if self.new_task.value:
            encrypted_task_name = encrypt_data(self.new_task.value)  # Encriptar a task
            task = Task(self.new_task.value, self.update, self.task_delete)  
            self.page.client_storage.set(f"todo.{encrypted_task_name}", False)  # guarda a task encriptada
            self.tasks.append(task)
            self.tasks_view.controls.append(task)
            self.new_task.value = ""
            self.update()



    def task_delete(self, task):
        if task in self.tasks:
            self.tasks.remove(task)
            
        if task in self.tasks_view.controls:
            self.tasks_view.controls.remove(task)
            
        self.page.client_storage.remove(f"todo.{task.task_name}")  # Remove do armazenamento local do cliente
        self.update()
 

    def clear_clicked(self, e):
        self.tasks = [task for task in self.tasks if not task.completed]
        self.update()
  

    def update(self):
        count = 0
        status = self.filter.tabs[self.filter.selected_index].text.lower()
        for task in self.tasks:
            task.visible = (
                status == "all" or
                (status == "active" and not task.completed) or
                (status == "completed" and task.completed)
            )
            if not task.completed:
                count += 1
        self.items_left.value = f"{count} items left"
        self.tasks_view.controls = [task for task in self.tasks if task.visible]
        super().update() 
    
        
    def tabs_changed(self, e):
        self.update()
        
                
def main(page: Page):
    todo_app = TodoApp(page) 

    provider = GitHubOAuthProvider(
        client_id=os.getenv("GITHUB_CLIENT_ID"),
        client_secret=os.getenv("GITHUB_CLIENT_SECRET"),
        redirect_url="https://tb-todo.fly.dev/api/oauth/redirect",
    )

    def login_button_click(e):
        page.login(provider)

    def on_login(e: LoginEvent): 
        if not e.error:
            toggle_login_buttons()
            page.add(todo_app)

    def logout_button_click(e):
        page.logout()

    def on_logout(e):
        toggle_login_buttons()
        page.remove(todo_app)  
        
        
    def toggle_login_buttons(): #login button ta visivel quando nao esta autenticada 
        login_button.visible = page.auth is None
        logout_button.visible = page.auth is not None
        page.update()

    login_button = ElevatedButton("Login with GitHub", on_click=login_button_click)
    logout_button = ElevatedButton("Logout", on_click=logout_button_click)
    toggle_login_buttons()
    page.on_login = on_login
    page.on_logout = on_logout
    page.add(login_button, logout_button)
    page.horizontal_alignment=ft.CrossAxisAlignment.CENTER
    #ft.SafeArea

ft.app(target=main, port=8080, view=ft.WEB_BROWSER)