import flet as ft
from flet import ElevatedButton, Row, Text, colors
import sympy as sp
import math
import datetime
import pyperclip
import json
import random 



class CalculatorApp(ft.UserControl):
    def __init__(self):
        super().__init__()
        self.history = []
        self.history_visible = False
    

    max_size_historico=10

    def build(self):
        self.reset()
        self.expression = Text(value="", color=colors.WHITE, size=14)
        self.result = Text(value="", color=colors.WHITE, size=20)
        self.history_list = ft.Column(visible=self.history_visible)

        def button_clicked(e):
            self.button_clicked(e)

        def toggle_history(e):
            self.history_visible = not self.history_visible
            self.history_list.visible = self.history_visible
            self.update()

        return ft.Column(

            controls=[
                Row(controls=[self.expression]),
                Row(controls=[self.result]),
                Row(controls=[self.history_list]),

                Row(
                    controls=[
                        ElevatedButton(text="AC", on_click=button_clicked, data="AC"),
                        ElevatedButton(text="+/-", on_click=button_clicked, data="+/-"),
                        ElevatedButton(text="(", on_click=button_clicked, data="("),
                        ElevatedButton(text=")", on_click=button_clicked, data=")"),
                        
                    ]
                ),

                Row(
                    controls=[
                        ElevatedButton(text="%", on_click=button_clicked, data="%"),
                        ElevatedButton(text="/", on_click=button_clicked, data="/"),
                        ElevatedButton(text="⬅️", on_click=button_clicked, data="backspace"),
                        ElevatedButton(text="CE", on_click=button_clicked, data="clear_entry"),
                        
                    ]
                ),  
                Row(
                    controls=[
                        ElevatedButton(text="√", on_click=button_clicked, data="raiz"),
                        ElevatedButton(text="|x|", on_click=button_clicked, data="modulo"),
                        ElevatedButton(text="random", on_click=button_clicked, data="random"),
                        ElevatedButton(text="!", on_click=button_clicked, data="!"),
                        
                    ]
                ),        

                Row(
                    controls=[
                        ElevatedButton(text="7", on_click=button_clicked, data="7"),
                        ElevatedButton(text="8", on_click=button_clicked, data="8"),
                        ElevatedButton(text="9", on_click=button_clicked, data="9"),
                        ElevatedButton(text="*", on_click=button_clicked, data="*"),
                    ]
                ),
                Row(
                    controls=[
                        ElevatedButton(text="4", on_click=button_clicked, data="4"),
                        ElevatedButton(text="5", on_click=button_clicked, data="5"),
                        ElevatedButton(text="6", on_click=button_clicked, data="6"),
                        ElevatedButton(text="-", on_click=button_clicked, data="-"),
                    ]
                ),
                Row(
                    controls=[
                        ElevatedButton(text="1", on_click=button_clicked, data="1"),
                        ElevatedButton(text="2", on_click=button_clicked, data="2"),
                        ElevatedButton(text="3", on_click=button_clicked, data="3"),
                        ElevatedButton(text="+", on_click=button_clicked, data="+"),
                    ]
                ),
                Row(
                    controls=[
                        ElevatedButton(text="0", on_click=button_clicked, data="0"),
                        ElevatedButton(text=".", on_click=button_clicked, data="."),
                        ElevatedButton(text="=", on_click=button_clicked, data="="),
                        
                    ]
                ),
                Row(
                    controls=[
                        ElevatedButton(text="Mostrar/Ocultar Histórico", on_click=toggle_history),
                        Row(controls=[self.history_list]),
                    ]
                ),
            ]

        )
    
    def did_mount(self):
        keys = self.page.client_storage.get_keys("calculation_")
        for idx, key in enumerate(keys, start=1):
            calculation_json = self.page.client_storage.get(key)
            calculation = json.loads(calculation_json, object_hook=self.json_deserial)
            self.history.append(calculation)
            # Assuming calculation is a dictionary containing necessary data
            history_item = ft.Row(
                controls=[
                    ft.Text(value=str(idx) + ""),
                    ft.Text(value=str(calculation["timestamp"])),
                    ft.Text(value=calculation["expression"] + " = " + calculation["result"]),
                    ft.ElevatedButton(text="Apagar", on_click=self.delete_calc, data=str(idx)),  
                    ft.ElevatedButton(text="Copiar", on_click=self.copy_resul, data=calculation["result"])
                ]
            )
            self.history_list.controls.append(history_item)
        self.update()

     
    def delete_calc(self, e):
        idx = int(e.control.data)    
        del self.history[idx - 1]
        key = f"calculation_{idx}"
        self.page.client_storage.remove(key)
        self.update_history()
        self.update()

    def copy_resul(self, e):
        result_to_copy = e.control.data
        pyperclip.copy(result_to_copy)

    def update_history(self):
        # Atualiza a exibição do histórico na interface do usuário
        self.history_list.controls.clear()
        for idx, calculation in enumerate(self.history, start=1):
            
            history_item = ft.Row(
                controls=[
                    ft.Text(value=str(idx)),  # Índice do cálculo
                    ft.Text(value=calculation["timestamp"].strftime("%Y-%m-%d %H:%M:%S")),  # Data e hora do cálculo
                    ft.Text(value=calculation["expression"] + " = " + calculation["result"]),
                    ft.ElevatedButton(text="Apagar", on_click=self.delete_calc, data=idx),
                    ft.ElevatedButton(text="Copiar", on_click=self.copy_resul, data=calculation["result"])  # Botão para copiar o resultado
                ]
            )
            self.history_list.controls.append(history_item)


   
    def add_calculation(self, expression, result):
        calculation = {
            "timestamp": datetime.datetime.now(),
            "expression": expression,
            "result": result
        }
        self.history.insert(0, calculation)
        if len (self.history)> self.max_size_historico:
            self.history.pop()
        self.update_history()
        self.save_history_to_local_storage()


    def save_history_to_local_storage(self):
        # Store each calculation item separately in local storage
        for idx, calculation in enumerate(self.history, start=1):
            key = f"calculation_{idx}"  # Generate a unique key for each calculation
            calculation_json = json.dumps(calculation, default=self.json_serial)
            self.page.client_storage.set(key, calculation_json)
            
        
    def load_history_from_local_storage(self):
        
        self.history.clear()
        
        
        for key in self.page.client_storage.keys():
            if key.startswith("calculation_"):
                calculation_json = self.page.client_storage.get(key)
                calculation = json.loads(calculation_json, object_hook=self.json_deserial)
                self.history.append(calculation)
        
        # Update the history display
        self.update_history()
        self.update()
            

    def json_serial(self, obj):
        """Função de serialização personalizada para objetos datetime."""
        if isinstance(obj, datetime.datetime):
            return obj.isoformat()  # Converte datetime para string no formato ISO
        raise TypeError("Tipo de objeto não serializável")


    def json_deserial(self, json_dict):
        """Função de desserialização personalizada para objetos datetime."""
        if 'timestamp' in json_dict:
            json_dict['timestamp'] = datetime.datetime.fromisoformat(json_dict['timestamp'])  # Converte string ISO de volta para datetime
        return json_dict
  

    def button_clicked(self, e):
        data = e.control.data

        if data == "random":
            random_number = random.uniform(0, 100)
           
            unidades = round(random_number)
            self.expression.value = str(unidades)


        elif data == "!":  
            try:
                if self.expression.value:
                    number = int(eval(self.expression.value))
                    factorial_value = math.factorial(number)
                    self.result.value = str(factorial_value)
                    self.expression.value = f"{number}!"
                else:
                    self.result.value = "Error: No number to calculate factorial"
            except ValueError:
                self.result.value = "Error: Invalid expression for factorial"


        if data == "modulo":
            try:
                #temos que ver se ja ta la do resultado ou se vai de primeira
                if self.result.value:
                    current_value = float(self.result.value)
                elif self.expression.value:
                    current_value = float(self.expression.value)
                else:
                    current_value = 0

                self.result.value = str(abs(current_value))
                self.expression.value = "|" + str(current_value) + "|"

            except ValueError:

                self.result.value = "Erro"


        if data == "raiz":
            try:
                #temos que ver se ja ta la do resultado ou se vai de primeira
                if self.result.value:
                    current_value = float(self.result.value)
                elif self.expression.value:
                    current_value = float(self.expression.value)
                else:
                    current_value = 0

                current_value = float(self.result.value)
                self.result.value = str(math.sqrt(current_value))
                self.expression.value = "√(" + str(current_value) + ")"

            except ValueError:
                self.result.value = "Erro"


        if data == "clear_entry":
             #vai encontrar o ultimo espaço imagina tens 123 + 456 isto vai encontrar o 456 e apaga
            #o rfind retorna o ultimo indice do ultimo espaço encontrado se nao houver retorna -1
            #metodo rfind que sempre que nao encontra o que foi definido a procurar retorna -1
            last_space_idx = self.expression.value.rfind(" ")
            #Se last_space_idx for diferente de -1, significa que um espaço foi encontrado.
            if last_space_idx != -1:  
                self.expression.value = self.expression.value[:last_space_idx]
            else:  #so tem uma entrada
                self.expression.value = ""


        if data == "backspace":
            self.expression.value = self.expression.value[:-1]


        if self.result.value == "Error" or data == "AC":
            self.add_calculation(self.expression.value, self.result.value)
            self.update_history()  
            self.result.value = ""
            self.expression.value = ""
            self.reset()


        elif data in ("1", "2", "3", "4", "5", "6", "7", "8", "9", "0", ".", "(", ")"):
            self.expression.value += data


        elif data in ("+", "-", "*", "/"):
            self.expression.value += " " + data + " "


        elif data in ("="):
            self.expression.value = "(" + self.expression.value + ")"
            self.result.value = self.calculate(self.expression.value)
            self.reset()


        elif data in ("%"):
            self.result.value = float(self.result.value) / 100
            self.expression.value += " " + data
            self.reset()


        elif data in ("+/-"):
            if float(self.result.value) > 0:
                self.result.value = "-" + str(self.result.value)
            elif float(self.result.value) < 0:
                self.result.value = str(
                    self.format_number(abs(float(self.result.value)))
                )
            self.expression.value = self.result.value

        self.update()


    def format_number(self, num):
        if num % 1 == 0:  # Se o número for um inteiro
            return '{:,}'.format(int(num)).replace(',', ' ')  # Use format para separar milhares e substitua vírgula por espaço
        else:  # Para nao inteiros
            # Primeiro, formate o número com 6 dígitos após a vírgula, remova zeros à direita e o ponto decimal se for o caso
            formatted_float = '{:.6f}'.format(num).rstrip('0').rstrip('.')
            return formatted_float  


    def calculate(self,expression):
        try:
            sympy_expression=sp.sympify(expression)
            result = sympy_expression.evalf()
            return self.format_number(result)
        except ZeroDivisionError:
            return "Nao podes dividir por zero"
        except Exception:
            return "Erro"


    def reset(self):
        self.operator = "+"
        self.operand1 = 0
        self.new_operand = True


def main(page: ft.Page):
    page.title = "Calc App"
    calc = CalculatorApp()
    page.add(calc)
    
ft.app(target=main, port=8080, view=ft.WEB_BROWSER)
